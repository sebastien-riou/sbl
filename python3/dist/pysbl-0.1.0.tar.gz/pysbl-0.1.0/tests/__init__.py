from pysbl import SBL
import sys
import binascii

sbl_demo_main()
