# pysbl

Library for controlling embedded devices using SBL 

## Dependencies
intelhex
serial
